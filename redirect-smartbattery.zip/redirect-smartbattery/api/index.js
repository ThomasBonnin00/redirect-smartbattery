export default function handler(req, res) {
  res.redirect(302, 'https://6e8e5506-815c-480b-b8f4-091b4adf0802-00-qz8oyb5q6yls.janeway.replit.dev');
}